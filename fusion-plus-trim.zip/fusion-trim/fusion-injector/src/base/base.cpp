#include "base.h"

#include "folder/folder.h"

Base::Base()
{
	window.Init(); // initialize the window
	FolderManager::GetFusionFolder(); // ensure the fusion folder exists
}

void Base::Run()
{
	while (window.Update()) // update the window
	{
	}
}

void Base::Cleanup()
{
	window.Cleanup(); // cleanup the window
}
