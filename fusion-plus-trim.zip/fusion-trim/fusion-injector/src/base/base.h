#pragma once

#include "window/window.h"
#include <string>

#define INJECTOR_VERSION "0.0.4-trim"

class Base
{
public:
	Base();
	void Run();
	void Cleanup();

private:
	Window window;
};